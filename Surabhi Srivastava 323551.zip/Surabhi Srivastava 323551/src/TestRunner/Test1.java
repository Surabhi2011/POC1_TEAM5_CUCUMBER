package TestRunner;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features="FEATURE",glue="STEP_DEF_PKG")
public class Test1 extends AbstractTestNGCucumberTests {}


